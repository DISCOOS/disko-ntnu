var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":59,"id":483,"methods":[{"el":25,"sc":9,"sl":23},{"el":30,"sc":9,"sl":28},{"el":35,"sc":9,"sl":33},{"el":40,"sc":9,"sl":38},{"el":45,"sc":9,"sl":43},{"el":52,"sc":5,"sl":50},{"el":56,"sc":5,"sl":54}],"name":"LogicalOperator","sl":21}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_456":{"methods":[{"sl":23},{"sl":28},{"sl":33},{"sl":38},{"sl":43},{"sl":50},{"sl":54}],"name":"compareWithComparator","pass":true,"statements":[{"sl":24},{"sl":29},{"sl":34},{"sl":39},{"sl":44},{"sl":51},{"sl":55}]},"test_509":{"methods":[{"sl":23},{"sl":28},{"sl":33},{"sl":38},{"sl":43},{"sl":50},{"sl":54}],"name":"compareWithComparator","pass":true,"statements":[{"sl":24},{"sl":29},{"sl":34},{"sl":39},{"sl":44},{"sl":51},{"sl":55}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [509, 456], [509, 456], [], [], [], [509, 456], [509, 456], [], [], [], [509, 456], [509, 456], [], [], [], [509, 456], [509, 456], [], [], [], [509, 456], [509, 456], [], [], [], [], [], [509, 456], [509, 456], [], [], [509, 456], [509, 456], [], [], [], []]
