var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":39,"id":2104,"methods":[{"el":30,"sc":5,"sl":28},{"el":34,"sc":5,"sl":32},{"el":38,"sc":5,"sl":36}],"name":"InstanceOf","sl":22}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_222":{"methods":[{"sl":28},{"sl":32}],"name":"testCapture_2617107","pass":true,"statements":[{"sl":29},{"sl":33}]},"test_229":{"methods":[{"sl":28},{"sl":32}],"name":"andOverloaded","pass":true,"statements":[{"sl":29},{"sl":33}]},"test_273":{"methods":[{"sl":28},{"sl":32},{"sl":36}],"name":"constraints","pass":true,"statements":[{"sl":29},{"sl":33},{"sl":37}]},"test_321":{"methods":[{"sl":28},{"sl":32}],"name":"notOverloaded","pass":true,"statements":[{"sl":29},{"sl":33}]},"test_322":{"methods":[{"sl":28},{"sl":32}],"name":"notOverloaded","pass":true,"statements":[{"sl":29},{"sl":33}]},"test_38":{"methods":[{"sl":28},{"sl":32},{"sl":36}],"name":"constraints","pass":true,"statements":[{"sl":29},{"sl":33},{"sl":37}]},"test_436":{"methods":[{"sl":28},{"sl":32}],"name":"testCapture_2617107","pass":true,"statements":[{"sl":29},{"sl":33}]},"test_82":{"methods":[{"sl":28},{"sl":32}],"name":"andOverloaded","pass":true,"statements":[{"sl":29},{"sl":33}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [436, 222, 273, 321, 82, 38, 322, 229], [436, 222, 273, 321, 82, 38, 322, 229], [], [], [436, 222, 273, 321, 82, 38, 322, 229], [436, 222, 273, 321, 82, 38, 322, 229], [], [], [273, 38], [273, 38], [], []]
