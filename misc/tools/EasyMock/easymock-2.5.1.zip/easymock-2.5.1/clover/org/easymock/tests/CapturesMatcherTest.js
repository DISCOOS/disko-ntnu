var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":76,"id":3780,"methods":[{"el":43,"sc":5,"sl":38},{"el":48,"sc":5,"sl":45},{"el":71,"sc":5,"sl":50},{"el":75,"sc":5,"sl":73}],"name":"CapturesMatcherTest","sl":30}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_449":{"methods":[{"sl":50},{"sl":73}],"name":"test","pass":true,"statements":[{"sl":53},{"sl":54},{"sl":56},{"sl":58},{"sl":60},{"sl":61},{"sl":62},{"sl":64},{"sl":66},{"sl":68},{"sl":69},{"sl":70},{"sl":74}]},"test_866":{"methods":[{"sl":50},{"sl":73}],"name":"test","pass":true,"statements":[{"sl":53},{"sl":54},{"sl":56},{"sl":58},{"sl":60},{"sl":61},{"sl":62},{"sl":64},{"sl":66},{"sl":68},{"sl":69},{"sl":70},{"sl":74}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [866, 449], [], [], [866, 449], [866, 449], [], [866, 449], [], [866, 449], [], [866, 449], [866, 449], [866, 449], [], [866, 449], [], [866, 449], [], [866, 449], [866, 449], [866, 449], [], [], [866, 449], [866, 449], [], []]
