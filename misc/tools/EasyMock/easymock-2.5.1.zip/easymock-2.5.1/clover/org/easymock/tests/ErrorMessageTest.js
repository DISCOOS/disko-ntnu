var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":56,"id":3852,"methods":[{"el":31,"sc":5,"sl":25},{"el":39,"sc":5,"sl":33},{"el":47,"sc":5,"sl":41},{"el":55,"sc":5,"sl":49}],"name":"ErrorMessageTest","sl":23}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_192":{"methods":[{"sl":49}],"name":"testAppendTo_matchingMultiple","pass":true,"statements":[{"sl":51},{"sl":52},{"sl":53},{"sl":54}]},"test_280":{"methods":[{"sl":25}],"name":"testGetters","pass":true,"statements":[{"sl":27},{"sl":28},{"sl":29},{"sl":30}]},"test_300":{"methods":[{"sl":49}],"name":"testAppendTo_matchingMultiple","pass":true,"statements":[{"sl":51},{"sl":52},{"sl":53},{"sl":54}]},"test_615":{"methods":[{"sl":25}],"name":"testGetters","pass":true,"statements":[{"sl":27},{"sl":28},{"sl":29},{"sl":30}]},"test_664":{"methods":[{"sl":41}],"name":"testAppendTo_matchingNone","pass":true,"statements":[{"sl":43},{"sl":44},{"sl":45},{"sl":46}]},"test_698":{"methods":[{"sl":41}],"name":"testAppendTo_matchingNone","pass":true,"statements":[{"sl":43},{"sl":44},{"sl":45},{"sl":46}]},"test_759":{"methods":[{"sl":33}],"name":"testAppendTo_matchingOne","pass":true,"statements":[{"sl":35},{"sl":36},{"sl":37},{"sl":38}]},"test_991":{"methods":[{"sl":33}],"name":"testAppendTo_matchingOne","pass":true,"statements":[{"sl":35},{"sl":36},{"sl":37},{"sl":38}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [615, 280], [], [615, 280], [615, 280], [615, 280], [615, 280], [], [], [991, 759], [], [991, 759], [991, 759], [991, 759], [991, 759], [], [], [698, 664], [], [698, 664], [698, 664], [698, 664], [698, 664], [], [], [300, 192], [], [300, 192], [300, 192], [300, 192], [300, 192], [], []]
