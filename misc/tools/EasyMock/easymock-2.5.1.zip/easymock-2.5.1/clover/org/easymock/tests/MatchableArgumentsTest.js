var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":56,"id":3938,"methods":[{"el":37,"sc":5,"sl":33},{"el":55,"sc":5,"sl":39}],"name":"MatchableArgumentsTest","sl":27}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_678":{"methods":[{"sl":39}],"name":"testEquals","pass":true,"statements":[{"sl":41},{"sl":44},{"sl":46},{"sl":49},{"sl":53},{"sl":54}]},"test_788":{"methods":[{"sl":39}],"name":"testEquals","pass":true,"statements":[{"sl":41},{"sl":44},{"sl":46},{"sl":49},{"sl":53},{"sl":54}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [788, 678], [], [788, 678], [], [], [788, 678], [], [788, 678], [], [], [788, 678], [], [], [], [788, 678], [788, 678], [], []]
