var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":60,"id":3977,"methods":[{"el":35,"sc":5,"sl":30},{"el":41,"sc":5,"sl":37},{"el":47,"sc":5,"sl":43},{"el":53,"sc":5,"sl":49},{"el":59,"sc":5,"sl":55}],"name":"NiceMockControlTest","sl":25}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_12":{"methods":[{"sl":55}],"name":"defaultReturnValueObject","pass":true,"statements":[{"sl":57},{"sl":58}]},"test_169":{"methods":[{"sl":37}],"name":"defaultReturnValueBoolean","pass":true,"statements":[{"sl":39},{"sl":40}]},"test_215":{"methods":[{"sl":37}],"name":"defaultReturnValueBoolean","pass":true,"statements":[{"sl":39},{"sl":40}]},"test_370":{"methods":[{"sl":55}],"name":"defaultReturnValueObject","pass":true,"statements":[{"sl":57},{"sl":58}]},"test_510":{"methods":[{"sl":43}],"name":"defaultReturnValueFloat","pass":true,"statements":[{"sl":45},{"sl":46}]},"test_739":{"methods":[{"sl":43}],"name":"defaultReturnValueFloat","pass":true,"statements":[{"sl":45},{"sl":46}]},"test_878":{"methods":[{"sl":49}],"name":"defaultReturnValueDouble","pass":true,"statements":[{"sl":51},{"sl":52}]},"test_972":{"methods":[{"sl":49}],"name":"defaultReturnValueDouble","pass":true,"statements":[{"sl":51},{"sl":52}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [215, 169], [], [215, 169], [215, 169], [], [], [739, 510], [], [739, 510], [739, 510], [], [], [878, 972], [], [878, 972], [878, 972], [], [], [12, 370], [], [12, 370], [12, 370], [], []]
