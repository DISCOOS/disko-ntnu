var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"el":77,"id":4208,"methods":[{"el":35,"sc":5,"sl":31},{"el":50,"sc":5,"sl":37},{"el":65,"sc":5,"sl":52},{"el":76,"sc":5,"sl":67}],"name":"RecordStateInvalidStateChangeTest","sl":26}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_241":{"methods":[{"sl":67}],"name":"verifyWithoutActivation","pass":true,"statements":[{"sl":69},{"sl":70},{"sl":73}]},"test_493":{"methods":[{"sl":37}],"name":"activateWithoutReturnValue","pass":true,"statements":[{"sl":39},{"sl":40},{"sl":41},{"sl":44},{"sl":47}]},"test_548":{"methods":[{"sl":37}],"name":"activateWithoutReturnValue","pass":true,"statements":[{"sl":39},{"sl":40},{"sl":41},{"sl":44},{"sl":47}]},"test_589":{"methods":[{"sl":67}],"name":"verifyWithoutActivation","pass":true,"statements":[{"sl":69},{"sl":70},{"sl":73}]},"test_749":{"methods":[{"sl":52}],"name":"secondCallWithoutReturnValue","pass":true,"statements":[{"sl":54},{"sl":55},{"sl":56},{"sl":59},{"sl":62}]},"test_897":{"methods":[{"sl":52}],"name":"secondCallWithoutReturnValue","pass":true,"statements":[{"sl":54},{"sl":55},{"sl":56},{"sl":59},{"sl":62}]}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [493, 548], [], [493, 548], [493, 548], [493, 548], [], [], [493, 548], [], [], [493, 548], [], [], [], [], [749, 897], [], [749, 897], [749, 897], [749, 897], [], [], [749, 897], [], [], [749, 897], [], [], [], [], [241, 589], [], [241, 589], [241, 589], [], [], [241, 589], [], [], [], []]
