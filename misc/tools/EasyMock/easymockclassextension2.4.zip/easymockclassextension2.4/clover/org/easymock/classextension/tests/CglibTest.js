var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"id":360,"sl":20,"methods":[{"sl":27,"el":34,"sc":5},{"sl":36,"el":58,"sc":5},{"sl":38,"el":41,"sc":13}],"el":59,"name":"CglibTest"}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_35":{"methods":[{"sl":27},{"sl":36}],"name":"test","statements":[{"sl":30},{"sl":31},{"sl":33},{"sl":37},{"sl":44},{"sl":45},{"sl":46},{"sl":48},{"sl":50},{"sl":52},{"sl":55},{"sl":57}],"pass":true}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [35], [], [], [35], [35], [], [35], [], [], [35], [35], [], [], [], [], [], [], [35], [35], [35], [], [35], [], [35], [], [35], [], [], [35], [], [35], [], []]
