var clover = new Object();

// JSON: {classes : [{name, id, sl, el,  methods : [{sl, el}, ...]}, ...]}
clover.pageData = {"classes":[{"id":127,"sl":20,"methods":[{"sl":22,"el":24,"sc":5},{"sl":26,"el":28,"sc":5},{"sl":30,"el":35,"sc":5},{"sl":37,"el":44,"sc":5},{"sl":46,"el":54,"sc":5},{"sl":56,"el":60,"sc":5}],"el":61,"name":"ClassInstantiatorFactoryTest"}]}

// JSON: {test_ID : {"methods": [ID1, ID2, ID3...], "name" : "testXXX() void"}, ...};
clover.testTargets = {"test_84":{"methods":[{"sl":56}],"name":"getJVM","statements":[{"sl":58}],"pass":true},"test_39":{"methods":[{"sl":30}],"name":"getInstantiator_Default","statements":[{"sl":32},{"sl":34}],"pass":true},"test_0":{"methods":[{"sl":46}],"name":"getInstantiator_BackToDefault","statements":[{"sl":48},{"sl":50},{"sl":51},{"sl":53}],"pass":true},"test_17":{"methods":[{"sl":37}],"name":"getInstantiator_Overriden","statements":[{"sl":39},{"sl":41},{"sl":43}],"pass":true}}

// JSON: { lines : [{tests : [testid1, testid2, testid3, ...]}, ...]};
clover.srcFileLines = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [39], [], [39], [], [39], [], [], [17], [], [17], [], [17], [], [17], [], [], [0], [], [0], [], [0], [0], [], [0], [], [], [84], [], [84], [], [], []]
