package com.diddlebits.gpslib4j.Garmin;

public class UnknownPacketException extends Exception {
	
}