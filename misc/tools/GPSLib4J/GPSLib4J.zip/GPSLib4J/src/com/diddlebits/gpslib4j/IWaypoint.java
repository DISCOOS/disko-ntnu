package com.diddlebits.gpslib4j;

public interface IWaypoint extends IPosition {
	public String getName();
}