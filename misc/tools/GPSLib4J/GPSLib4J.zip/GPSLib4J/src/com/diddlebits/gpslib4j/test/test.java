package com.diddlebits.gpslib4j.test;

public class test {
	public static void main(String args[]) {
		System.out.println("Short Max-value: " + Short.MAX_VALUE);
	}
}